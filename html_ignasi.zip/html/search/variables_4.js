var searchData=
[
  ['problemes_5fintentats_267',['problemes_intentats',['../class_usuari.html#adf16955380a143571e2f009662498c82',1,'Usuari']]],
  ['problems_268',['problems',['../class_sessio.html#ae3d7b195e1a599bd5a3305c0042b965b',1,'Sessio']]]
];
