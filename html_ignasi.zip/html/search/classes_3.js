var searchData=
[
  ['usuari_139',['Usuari',['../class_usuari.html',1,'']]]
];
