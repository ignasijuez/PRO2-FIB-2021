var searchData=
[
  ['decrementa_5fusuaris_5finscrits_218',['decrementa_usuaris_inscrits',['../class_cjt___cursos.html#ad20267a0f7187ffee41322155ed297e5',1,'Cjt_Cursos']]]
];
