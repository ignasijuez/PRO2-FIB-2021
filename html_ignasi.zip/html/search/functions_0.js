var searchData=
[
  ['actualitza_5fprbl_5fenv_157',['actualitza_prbl_env',['../class_sessio.html#aa48ed94fbaf82831413dc7c566cddb92',1,'Sessio']]],
  ['actualitzar_5fenviaments_5ftotals_158',['actualitzar_enviaments_totals',['../class_usuari.html#adbd40ceab5b8fab843e0c9c52c779dcc',1,'Usuari']]],
  ['actualitzar_5fenviaments_5fverds_159',['actualitzar_enviaments_verds',['../class_usuari.html#ae124b4cca554f790aa9438b446b852d3',1,'Usuari']]],
  ['actualitzar_5fproblemes_5fenviables_160',['actualitzar_problemes_enviables',['../class_usuari.html#a4ce76daaac070209edd85de3a44bbf50',1,'Usuari']]],
  ['actualitzar_5fstats_161',['actualitzar_stats',['../class_cjt___problemes.html#a31a23d7ae10913af7091c1bfa8a02b23',1,'Cjt_Problemes']]],
  ['actualitzar_5fusuaris_5fdone_162',['actualitzar_usuaris_done',['../class_curs.html#a8600ee4df53786bae79609c5514df9bf',1,'Curs']]],
  ['actualitzar_5fusuaris_5finscrits_163',['actualitzar_usuaris_inscrits',['../class_curs.html#a505ad4588e4f059fdb5733a567d6db10',1,'Curs']]],
  ['actualizar_5fratio_164',['actualizar_ratio',['../class_problema.html#ac69c93803060197792ef88212aa637d8',1,'Problema']]],
  ['afegir_5fproblema_165',['afegir_problema',['../class_cjt___problemes.html#a0a53adb3f30900564f300e33c8a78158',1,'Cjt_Problemes']]],
  ['afegir_5fproblema_5fdic_166',['afegir_problema_dic',['../class_cjt___problemes.html#a8c99baec8ad074a820b08634e5f6424e',1,'Cjt_Problemes']]],
  ['afegir_5fsessio_167',['afegir_sessio',['../class_cjt___sessions.html#aebc0963e59a7061ab1b28d7bb67f6ea3',1,'Cjt_Sessions']]],
  ['alta_5fusuari_168',['alta_usuari',['../class_cjt___usuaris.html#a1e492cd729f8a685b6a6619bf5fe7495',1,'Cjt_Usuaris']]],
  ['augmenta_5fusuaris_5fdone_169',['augmenta_usuaris_done',['../class_cjt___cursos.html#af204f2e6188efb7194382e4bb0366ba7',1,'Cjt_Cursos']]],
  ['augmenta_5fusuaris_5fincrits_170',['augmenta_usuaris_incrits',['../class_cjt___cursos.html#a951b6745fe1fc5a481455ab642aa02cf',1,'Cjt_Cursos']]]
];
