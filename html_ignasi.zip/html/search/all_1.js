var searchData=
[
  ['baixa_5fusuari_14',['baixa_usuari',['../class_cjt___usuaris.html#a4ef9920d40eb88d553c705b43b2aa8bd',1,'Cjt_Usuaris']]],
  ['borrar_5fproblema_15',['borrar_problema',['../class_cjt___problemes.html#a3f68726ecd673ae12386461ce89c682b',1,'Cjt_Problemes']]],
  ['buscar_5farrel_16',['buscar_arrel',['../class_cjt___sessions.html#a4722b30a938bba0b4b886eccb67cc18a',1,'Cjt_Sessions']]],
  ['buscar_5fmapa_17',['buscar_mapa',['../class_sessio.html#a3d463d4f485e414d32a6c803d17c4292',1,'Sessio']]],
  ['buscar_5fsessio_18',['buscar_sessio',['../class_cjt___cursos.html#a41439faac8401cfbce7f375648a1c47e',1,'Cjt_Cursos']]]
];
