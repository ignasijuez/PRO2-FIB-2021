var searchData=
[
  ['total_5fcorrect_5fsubmisions_272',['total_correct_submisions',['../class_problema.html#a1da176575e84d202d507e18370252677',1,'Problema']]],
  ['total_5fsubmisions_273',['total_submisions',['../class_problema.html#a42d06a2090a9b71ae7ac91203f8e1f86',1,'Problema']]]
];
