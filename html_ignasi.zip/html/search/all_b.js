var searchData=
[
  ['omplir_5fconjunts_105',['omplir_conjunts',['../class_cjt___sessions.html#aab3834d68b82847b8930713ed1f3c086',1,'Cjt_Sessions']]]
];
