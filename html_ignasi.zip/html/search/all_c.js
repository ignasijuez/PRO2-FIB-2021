var searchData=
[
  ['problema_106',['Problema',['../class_problema.html',1,'Problema'],['../class_problema.html#a9d81af5f3f42a1b4354ad8f3c022fca3',1,'Problema::Problema()'],['../class_problema.html#a69736829d95cc476a76d1a41250e2ceb',1,'Problema::Problema(string &amp;nom_problema)'],['../class_problema.html#a6b974898f09b3077d5c788c02103a93c',1,'Problema::Problema(string &amp;nom_problema, int env)']]],
  ['problema_2ecc_107',['Problema.cc',['../_problema_8cc.html',1,'']]],
  ['problema_2ehh_108',['Problema.hh',['../_problema_8hh.html',1,'']]],
  ['problema_5fi_109',['problema_i',['../class_cjt___sessions.html#ad878f0814123e3dd8db1e65a04b470a8',1,'Cjt_Sessions']]],
  ['problemes_5fenviables_5fusuari_110',['problemes_enviables_usuari',['../class_cjt___usuaris.html#a39f5966f2740ddb0846a030ee6fada9f',1,'Cjt_Usuaris']]],
  ['problemes_5fintentats_111',['problemes_intentats',['../class_usuari.html#adf16955380a143571e2f009662498c82',1,'Usuari']]],
  ['problemes_5fresolts_5fusuari_112',['problemes_resolts_usuari',['../class_cjt___usuaris.html#abc91cfca6bcbec79649c9144a4f8d03c',1,'Cjt_Usuaris']]],
  ['problems_113',['problems',['../class_sessio.html#ae3d7b195e1a599bd5a3305c0042b965b',1,'Sessio']]],
  ['program_2ecc_114',['program.cc',['../program_8cc.html',1,'']]]
];
