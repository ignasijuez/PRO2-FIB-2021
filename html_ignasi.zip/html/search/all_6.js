var searchData=
[
  ['genera_5fenviables_87',['genera_enviables',['../class_cjt___usuaris.html#af380de285c01b06b97b17f2037aae169',1,'Cjt_Usuaris']]]
];
