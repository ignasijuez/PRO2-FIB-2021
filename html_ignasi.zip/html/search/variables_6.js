var searchData=
[
  ['shippable_5fproblems_270',['shippable_problems',['../class_usuari.html#ab233286d899c320df975013c6d2af943',1,'Usuari']]],
  ['solved_5fproblems_271',['solved_problems',['../class_usuari.html#a2b63744a47f9d0453a2717722f29e8ee',1,'Usuari']]]
];
