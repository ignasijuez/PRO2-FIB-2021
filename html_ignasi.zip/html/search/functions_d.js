var searchData=
[
  ['searchs_249',['searchS',['../class_curs.html#a5d259f342766ac0ae0f637af494fcc88',1,'Curs']]],
  ['sessio_250',['Sessio',['../class_sessio.html#a2aeda3ca0902761f07d837538244539b',1,'Sessio::Sessio()'],['../class_sessio.html#a4e5463447ed7ce9a40d079f470d4b307',1,'Sessio::Sessio(string &amp;nom_sessio)']]]
];
