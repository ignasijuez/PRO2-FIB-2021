var searchData=
[
  ['usuari_252',['Usuari',['../class_usuari.html#ac6a1fbc3d6967c6de677580c60dfaaf4',1,'Usuari::Usuari()'],['../class_usuari.html#a7ca1d56b5f1d828c294827e98d50b90e',1,'Usuari::Usuari(string &amp;nom_usuari)']]],
  ['usuaris_5finscrits_253',['usuaris_inscrits',['../class_cjt___cursos.html#acab4ea6862a5e352eec5318f91b17211',1,'Cjt_Cursos']]]
];
