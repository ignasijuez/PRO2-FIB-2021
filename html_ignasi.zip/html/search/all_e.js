var searchData=
[
  ['searchs_116',['searchS',['../class_curs.html#a5d259f342766ac0ae0f637af494fcc88',1,'Curs']]],
  ['sessio_117',['Sessio',['../class_sessio.html',1,'Sessio'],['../class_sessio.html#a2aeda3ca0902761f07d837538244539b',1,'Sessio::Sessio()'],['../class_sessio.html#a4e5463447ed7ce9a40d079f470d4b307',1,'Sessio::Sessio(string &amp;nom_sessio)']]],
  ['sessio_2ecc_118',['Sessio.cc',['../_sessio_8cc.html',1,'']]],
  ['sessio_2ehh_119',['Sessio.hh',['../_sessio_8hh.html',1,'']]],
  ['shippable_5fproblems_120',['shippable_problems',['../class_usuari.html#ab233286d899c320df975013c6d2af943',1,'Usuari']]],
  ['solved_5fproblems_121',['solved_problems',['../class_usuari.html#a2b63744a47f9d0453a2717722f29e8ee',1,'Usuari']]]
];
