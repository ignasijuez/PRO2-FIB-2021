var searchData=
[
  ['list_5fsessions_91',['list_sessions',['../class_cjt___cursos.html#af8cb963a731447d5023c685f5071c8be',1,'Cjt_Cursos']]],
  ['llegir_92',['llegir',['../class_cjt___cursos.html#a771ec2b721d40785aacabace1ae8b92c',1,'Cjt_Cursos::llegir()'],['../class_cjt___problemes.html#a504b4a5fafcca23b875cb003dce6d98a',1,'Cjt_Problemes::llegir()'],['../class_cjt___sessions.html#afd179803d50583c4fd366994ed71f798',1,'Cjt_Sessions::llegir()'],['../class_cjt___usuaris.html#a0baf637ada05c11fba9e9231b7256e2a',1,'Cjt_Usuaris::llegir()'],['../class_curs.html#aa3d42b16d67b9f0d69d74ca2d0f0e544',1,'Curs::llegir()'],['../class_problema.html#a4a4ca5d0bdaee275002c8f9e367fb784',1,'Problema::llegir()'],['../class_sessio.html#a355490ba511b7d55279627cdf88577e5',1,'Sessio::llegir()'],['../class_usuari.html#a3611323cfd165010b286ee2cc09322ba',1,'Usuari::llegir()']]],
  ['llegir_5farbre_93',['llegir_arbre',['../class_sessio.html#a43ff435dc50e3879a882174c0d5fb190',1,'Sessio']]],
  ['llegir_5fnou_94',['llegir_nou',['../class_curs.html#a9a68efb28f29734d0f1e6e217a67a91d',1,'Curs']]],
  ['llegir_5fnou_5fcurs_95',['llegir_nou_curs',['../class_cjt___cursos.html#a8f793339f534797e3a495ce63d40b95c',1,'Cjt_Cursos']]]
];
