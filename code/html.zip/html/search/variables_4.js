var searchData=
[
  ['problemes_5fenviables_261',['problemes_enviables',['../class_usuari.html#a59638fa14003887e7e6354fcfe248dda',1,'Usuari']]],
  ['problemes_5fintentats_262',['problemes_intentats',['../class_usuari.html#adf16955380a143571e2f009662498c82',1,'Usuari']]],
  ['problemes_5fresolts_5fplataforma_263',['problemes_resolts_plataforma',['../class_usuari.html#a5f5a06f95c006ab6e5e86a33487ef742',1,'Usuari']]],
  ['problems_264',['problems',['../class_sessio.html#ae3d7b195e1a599bd5a3305c0042b965b',1,'Sessio']]]
];
