var searchData=
[
  ['usuari_122',['Usuari',['../class_usuari.html',1,'Usuari'],['../class_usuari.html#ac6a1fbc3d6967c6de677580c60dfaaf4',1,'Usuari::Usuari()'],['../class_usuari.html#a7ca1d56b5f1d828c294827e98d50b90e',1,'Usuari::Usuari(string &amp;nom_usuari)']]],
  ['usuari_2ecc_123',['Usuari.cc',['../_usuari_8cc.html',1,'']]],
  ['usuari_2ehh_124',['Usuari.hh',['../_usuari_8hh.html',1,'']]],
  ['usuaris_5fdone_125',['usuaris_done',['../class_curs.html#a0bc92586896001132767d0113d7642f1',1,'Curs']]],
  ['usuaris_5finscrits_126',['usuaris_inscrits',['../class_curs.html#a4c53154cdee736eb839bb0f04c033d64',1,'Curs::usuaris_inscrits()'],['../class_cjt___cursos.html#acab4ea6862a5e352eec5318f91b17211',1,'Cjt_Cursos::usuaris_inscrits()']]]
];
