var searchData=
[
  ['vp_270',['vP',['../class_sessio.html#af1b01a0d398075d038b93b1c32345a65',1,'Sessio']]],
  ['vs_271',['vS',['../class_curs.html#a4bd6af2d23bc680c5c80b3999664d9d1',1,'Curs']]]
];
