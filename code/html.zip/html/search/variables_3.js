var searchData=
[
  ['nom_258',['nom',['../class_problema.html#a6f588164528c2faa97c8c82df899f655',1,'Problema::nom()'],['../class_sessio.html#a548e4cad9e6cdb2c2f6ed67a856a3f82',1,'Sessio::nom()'],['../class_usuari.html#ae0e69c36a70bd70191ac9fbf4832329d',1,'Usuari::nom()']]],
  ['nombre_5fde_5fsessions_259',['nombre_de_sessions',['../class_curs.html#adfa92203f6b936dc71862ced21268fc1',1,'Curs']]],
  ['numeron_260',['numeroN',['../class_curs.html#ab88ff33fb303d5e9540a4e4890b07fcc',1,'Curs']]]
];
