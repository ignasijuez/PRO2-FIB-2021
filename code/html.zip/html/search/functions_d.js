var searchData=
[
  ['treure_5fcurs_245',['treure_curs',['../class_cjt___usuaris.html#a99f47616d7a6d78bbf9accade43c67a3',1,'Cjt_Usuaris']]]
];
