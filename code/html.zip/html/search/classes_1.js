var searchData=
[
  ['problema_134',['Problema',['../class_problema.html',1,'']]]
];
