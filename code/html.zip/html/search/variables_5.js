var searchData=
[
  ['ratio_265',['ratio',['../class_problema.html#acc3d2ce24418ad68650108de4b603d99',1,'Problema']]]
];
