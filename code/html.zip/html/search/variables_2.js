var searchData=
[
  ['mapa_256',['mapa',['../class_curs.html#ab086d65dabacbf2920e58be97e255440',1,'Curs']]],
  ['mapa_5fproblemes_257',['mapa_problemes',['../class_sessio.html#a8e1c3bfa5ad3711aa7f349803dc94318',1,'Sessio']]]
];
