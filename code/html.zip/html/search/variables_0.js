var searchData=
[
  ['cjt_5fcursos_248',['cjt_cursos',['../class_cjt___cursos.html#a906280bc922fbcdaa09cc16b9ecad9f2',1,'Cjt_Cursos']]],
  ['cjt_5fproblemes_249',['cjt_problemes',['../class_cjt___problemes.html#a6142483c8f38d099cadf99aed490c85a',1,'Cjt_Problemes']]],
  ['cjt_5fsessions_250',['cjt_sessions',['../class_cjt___sessions.html#a80f123154620d6de004251adfa0060fc',1,'Cjt_Sessions::cjt_sessions()'],['../class_curs.html#a8374dcf6321d01a801a5ecd1f3dd2731',1,'Curs::cjt_sessions()']]],
  ['cjt_5fusuaris_251',['cjt_usuaris',['../class_cjt___usuaris.html#ac9adc75b3cbdacd5df8cf79c023a7318',1,'Cjt_Usuaris']]],
  ['curs_252',['curs',['../class_usuari.html#ae74cef9f75b777ce237b2ee26c6789e1',1,'Usuari']]]
];
