var searchData=
[
  ['genera_5fenviables_84',['genera_enviables',['../class_cjt___usuaris.html#af380de285c01b06b97b17f2037aae169',1,'Cjt_Usuaris']]],
  ['genera_5fproblemes_5fenviables_85',['genera_problemes_enviables',['../class_usuari.html#a2e754cf27faef285788c08fe73c9433a',1,'Usuari']]]
];
