var searchData=
[
  ['usuaris_5fdone_268',['usuaris_done',['../class_curs.html#a0bc92586896001132767d0113d7642f1',1,'Curs']]],
  ['usuaris_5finscrits_269',['usuaris_inscrits',['../class_curs.html#a4c53154cdee736eb839bb0f04c033d64',1,'Curs']]]
];
