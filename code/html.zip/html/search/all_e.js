var searchData=
[
  ['total_5fcorrect_5fsubmisions_119',['total_correct_submisions',['../class_problema.html#a1da176575e84d202d507e18370252677',1,'Problema']]],
  ['total_5fsubmisions_120',['total_submisions',['../class_problema.html#a42d06a2090a9b71ae7ac91203f8e1f86',1,'Problema']]],
  ['treure_5fcurs_121',['treure_curs',['../class_cjt___usuaris.html#a99f47616d7a6d78bbf9accade43c67a3',1,'Cjt_Usuaris']]]
];
