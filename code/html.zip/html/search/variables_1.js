var searchData=
[
  ['enviaments_5ftotals_253',['enviaments_totals',['../class_usuari.html#ae161827ec242c42aadeabbac4431e86a',1,'Usuari']]],
  ['enviaments_5fverds_254',['enviaments_verds',['../class_usuari.html#af15957801e20e99faa7bb30946a66074',1,'Usuari']]],
  ['exercicis_255',['exercicis',['../class_sessio.html#a68563bf096f95b5e095d90a3e699bfc1',1,'Sessio']]]
];
