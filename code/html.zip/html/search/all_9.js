var searchData=
[
  ['main_96',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mapa_97',['mapa',['../class_curs.html#ab086d65dabacbf2920e58be97e255440',1,'Curs']]],
  ['mapa_5fproblemes_98',['mapa_problemes',['../class_sessio.html#a8e1c3bfa5ad3711aa7f349803dc94318',1,'Sessio']]]
];
